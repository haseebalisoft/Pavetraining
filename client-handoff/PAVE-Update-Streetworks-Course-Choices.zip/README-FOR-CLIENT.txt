PAVE — Update Streetworks Course choices (SharePoint)
=====================================================

Why this is needed
------------------
The app Course list is:
  Operative
  Supervisor
  Operative Reassessment
  Supervisor Reassessment

SharePoint still has old values (Unit 1, Refresher, etc.).
When those do not match, Save can fail or the Course field will not stick.

Who runs this
-------------
A Site Owner on:
  https://pavetraining.sharepoint.com/sites/PaveTrainingOperationAdmin

Commands
--------
1. Unzip this folder
2. Open PowerShell in this folder (address bar → type powershell)
3. npm install
4. node update-streetworks-course-choices.mjs --dry-run
5. node update-streetworks-course-choices.mjs
6. Sign in with the Site Owner Microsoft account when prompted
